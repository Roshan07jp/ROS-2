package com.roshan.ros

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
