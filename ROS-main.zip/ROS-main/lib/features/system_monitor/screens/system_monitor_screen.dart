import 'package:flutter/material.dart';

class SystemMonitorScreen extends StatelessWidget {
  const SystemMonitorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('System Monitor')),
      body: const Center(child: Text('System Monitor Screen - Coming Soon')),
    );
  }
}