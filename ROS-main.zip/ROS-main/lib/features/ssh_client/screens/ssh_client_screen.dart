import 'package:flutter/material.dart';

class SSHClientScreen extends StatelessWidget {
  const SSHClientScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SSH Client')),
      body: const Center(child: Text('SSH Client Screen - Coming Soon')),
    );
  }
}