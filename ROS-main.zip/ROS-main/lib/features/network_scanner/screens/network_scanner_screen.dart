import 'package:flutter/material.dart';

class NetworkScannerScreen extends StatelessWidget {
  const NetworkScannerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Network Scanner')),
      body: const Center(child: Text('Network Scanner Screen - Coming Soon')),
    );
  }
}