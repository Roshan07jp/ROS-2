import 'package:flutter/material.dart';

class BackupSyncScreen extends StatelessWidget {
  const BackupSyncScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Backup & Sync')),
      body: const Center(child: Text('Backup & Sync Screen - Coming Soon')),
    );
  }
}