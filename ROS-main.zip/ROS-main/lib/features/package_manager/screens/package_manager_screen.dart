import 'package:flutter/material.dart';

class PackageManagerScreen extends StatelessWidget {
  const PackageManagerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Package Manager')),
      body: const Center(child: Text('Package Manager Screen - Coming Soon')),
    );
  }
}